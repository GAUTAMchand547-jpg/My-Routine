GAUTAM HABIT PROTOCOL — ANDROID STUDIO PROJECT

This project wraps the Habit Protocol tracker in a native Android WebView. It includes the offline HTML app and its icons. The app stores check-ins in WebView local storage on the device.

BUILD AN APK
1. Install Android Studio on a computer.
2. Open this extracted GautamHabitProtocolAndroid folder as a project.
3. Allow Android Studio to download the Android Gradle Plugin and Android SDK (compile SDK 35).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally at app/build/outputs/apk/debug/app-debug.apk.

This source project is not itself an APK. Building requires Android SDK/Gradle downloads and a computer with Android Studio. No signing keys are included.
